import React from 'react'


export default Nav1
function Nav1() {
       return (
              <>
                     <div className="h-[4rem]">
                            <Image>
                                   <source src='bg.webp'>
                                   </source>
                            </Image>
                     </div>

              </>
       )
}




// width: 100%;
//     height: auto;
//     transform: translate(24rem, -25rem) rotateZ(270deg);

//     width: 1000px;
//     /* height: 1000px; */
//     background-color: 
// bg-gradient-to-r = gradient to right side 