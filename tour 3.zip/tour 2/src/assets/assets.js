import video from "./video.mp4"
import Img from "./Img.jpg"

export const assets = {
       video,Img
}